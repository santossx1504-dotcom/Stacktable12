package com.example.stacktable;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class TableScreen extends Screen {
    public record Row(String name, long total, int max) {
        String stacks() {
            long full = total / max;
            long rest = total % max;
            if (max == 1) return total + " (nao empilha)";
            if (full == 0) return rest + " (menos de 1)";
            return rest == 0 ? full + "" : full + " + " + rest;
        }
        long slots() { return (total + max - 1) / max; }
    }

    private static final int ROW_H = 12;
    private static final int TOP = 36;
    private static final int BOTTOM = 34;

    private final List<Row> rows;
    private int scroll = 0;

    public TableScreen(List<Row> rows) {
        super(Text.literal("Tabela de Stacks"));
        this.rows = rows;
    }

    @Override
    protected void init() {
        int bx = this.width - 70;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Fechar"), b -> this.close())
                .dimensions(bx, 8, 62, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Subir"), b -> scrollBy(-6))
                .dimensions(bx, this.height / 2 - 24, 62, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Descer"), b -> scrollBy(6))
                .dimensions(bx, this.height / 2 + 4, 62, 20).build());
    }

    private void scrollBy(int d) {
        int max = Math.max(0, rows.size() - visibleRows());
        scroll = Math.max(0, Math.min(max, scroll + d));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // sem blur
    }

    private int visibleRows() {
        return Math.max(1, (this.height - TOP - BOTTOM) / ROW_H);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double h, double v) {
        scrollBy(-(int) Math.signum(v) * 3);
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        TextRenderer tr = this.textRenderer;
        ctx.fill(0, 0, this.width, this.height, 0xE0101010);

        int left = this.width / 2 - 170;
        int cTotal = left + 190;
        int cStacks = left + 250;

        ctx.drawTextWithShadow(tr, "Tabela de Stacks", left, 10, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, "Item", left, 24, 0xFFFFD060);
        ctx.drawTextWithShadow(tr, "Total", cTotal, 24, 0xFFFFD060);
        ctx.drawTextWithShadow(tr, "Stacks", cStacks, 24, 0xFFFFD060);

        int y = TOP;
        int end = Math.min(rows.size(), scroll + visibleRows());
        for (int i = scroll; i < end; i++) {
            Row r = rows.get(i);
            if (i % 2 == 0) ctx.fill(left - 4, y - 2, left + 350, y + ROW_H - 2, 0x30FFFFFF);
            ctx.drawTextWithShadow(tr, r.name(), left, y, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, String.valueOf(r.total()), cTotal, y, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, r.stacks(), cStacks, y, 0xFF80FF80);
            y += ROW_H;
        }

        long totalItems = 0, slots = 0;
        for (Row r : rows) { totalItems += r.total(); slots += r.slots(); }
        long shulkers = (slots + 26) / 27;
        ctx.drawTextWithShadow(tr,
                "Itens: " + totalItems + "  |  Slots: " + slots + "  |  Shulkers (27 slots): " + shulkers,
                left, this.height - 24, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, "Use Subir/Descer ou a roda do mouse", left, this.height - 12, 0xFF909090);
        super.render(ctx, mouseX, mouseY, delta); // desenha os botoes
    }

    @Override
    public boolean shouldPause() { return false; }
}
