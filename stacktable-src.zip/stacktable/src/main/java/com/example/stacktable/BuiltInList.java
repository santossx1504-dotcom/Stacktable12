package com.example.stacktable;

import java.util.ArrayList;
import java.util.List;

/** Lista fixa tirada dos prints da lista de materiais (schematic '270k basalt farm'). */
public class BuiltInList {
    public static List<TableScreen.Row> rows() {
        return new ArrayList<>(List.of(
        new TableScreen.Row("Basalto", 738, 64),
        new TableScreen.Row("Barra de Ferro", 504, 64),
        new TableScreen.Row("Bloco de Ferro", 484, 64),
        new TableScreen.Row("Observador", 450, 64),
        new TableScreen.Row("Pó de Redstone", 263, 64),
        new TableScreen.Row("Vidro Branco", 255, 64),
        new TableScreen.Row("Pistão", 235, 64),
        new TableScreen.Row("Obsidiana", 180, 64),
        new TableScreen.Row("Repetidor de Redstone", 134, 64),
        new TableScreen.Row("Pistão Grudento", 116, 64),
        new TableScreen.Row("Bloco Musical", 111, 64),
        new TableScreen.Row("Caule Distorcido", 92, 64),
        new TableScreen.Row("Balde de Lava", 80, 1),
        new TableScreen.Row("Terra das Almas", 80, 64),
        new TableScreen.Row("Gelo Azul", 75, 64),
        new TableScreen.Row("Botão de Pedra", 49, 64),
        new TableScreen.Row("Trilho Elétrico", 45, 64),
        new TableScreen.Row("Muro de Tijolos de Pedra", 36, 64),
        new TableScreen.Row("Bloco de Slime", 26, 64),
        new TableScreen.Row("Alçapão de Ferro", 25, 64),
        new TableScreen.Row("Areia das Almas", 24, 64),
        new TableScreen.Row("Caminho de Terra", 24, 64),
        new TableScreen.Row("Laje de Pedra Lisa", 24, 64),
        new TableScreen.Row("Portão de Bétula", 24, 64),
        new TableScreen.Row("Funil", 15, 64),
        new TableScreen.Row("Comparador de Redstone", 13, 64),
        new TableScreen.Row("Terracota Vidrada Azul-Clara", 8, 64),
        new TableScreen.Row("Baú", 6, 64),
        new TableScreen.Row("Bloco de Redstone", 6, 64),
        new TableScreen.Row("Obsidiana Chorona", 5, 64),
        new TableScreen.Row("Hifas Distorcidas", 4, 64),
        new TableScreen.Row("Botão Distorcido", 2, 64),
        new TableScreen.Row("Alavanca", 1, 64),
        new TableScreen.Row("Botão Carmesim", 1, 64),
        new TableScreen.Row("Ejetor", 1, 64),
        new TableScreen.Row("Lâmpada de Redstone", 1, 64),
        new TableScreen.Row("Tocha de Redstone", 1, 64)
        ));
    }
}
