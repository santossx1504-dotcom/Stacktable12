package com.example.stacktable;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class StackTableMod implements ClientModInitializer {
    private static KeyBinding openKey;
    private static volatile boolean pendingOpen = false;
    private static volatile boolean useLitematica = false;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.stacktable.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.MISC));

        // Comandos /tabela e /stacktable (otimo pra celular, sem teclado)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            for (String name : new String[]{"tabela", "stacktable"}) {
                dispatcher.register(ClientCommandManager.literal(name)
                        .executes(ctx -> { useLitematica = false; pendingOpen = true; return 1; })
                        .then(ClientCommandManager.literal("litematica")
                                .executes(ctx -> { useLitematica = true; pendingOpen = true; return 1; })));
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                useLitematica = false;
                pendingOpen = true;
            }
            // Abre no tick seguinte, depois do chat fechar
            if (pendingOpen && client.currentScreen == null) {
                pendingOpen = false;
                open(client);
            }
        });
    }

    private void open(MinecraftClient client) {
        if (!useLitematica) {
            client.setScreen(new TableScreen(BuiltInList.rows()));
            return;
        }
        try {
            // Acessa o Litematica por reflexao: o mod compila sem depender dele.
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            Object list = dm.getMethod("getMaterialList").invoke(null);
            if (list == null) {
                msg(client, "Abra a lista de materiais do Litematica uma vez antes.");
                return;
            }
            List<?> entries = (List<?>) list.getClass().getMethod("getMaterialsAll").invoke(list);

            List<TableScreen.Row> rows = new ArrayList<>();
            for (Object e : entries) {
                ItemStack stack = (ItemStack) e.getClass().getMethod("getStack").invoke(e);
                long total = ((Number) e.getClass().getMethod("getCountTotal").invoke(e)).longValue();
                rows.add(new TableScreen.Row(stack.getName().getString(), total, Math.max(1, stack.getMaxCount())));
            }
            rows.sort((a, b) -> Long.compare(b.total(), a.total()));
            client.setScreen(new TableScreen(rows));
        } catch (Throwable t) {
            msg(client, "Stack Table: erro ao ler o Litematica (" + t + ")");
            t.printStackTrace();
        }
    }

    private static void msg(MinecraftClient client, String s) {
        if (client.player != null) client.player.sendMessage(Text.literal(s), false);
    }
}
